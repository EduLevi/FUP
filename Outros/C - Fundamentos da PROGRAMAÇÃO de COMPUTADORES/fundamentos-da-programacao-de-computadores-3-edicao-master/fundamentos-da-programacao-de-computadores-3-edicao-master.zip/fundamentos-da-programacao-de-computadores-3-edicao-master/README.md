# Fundamentos-da-Programa-o-de-Computadores-3Edicao
Exercicios do livro Fundamentos da programação de computadores: algoritmos, pascal, C/C++ 3ª Edição
