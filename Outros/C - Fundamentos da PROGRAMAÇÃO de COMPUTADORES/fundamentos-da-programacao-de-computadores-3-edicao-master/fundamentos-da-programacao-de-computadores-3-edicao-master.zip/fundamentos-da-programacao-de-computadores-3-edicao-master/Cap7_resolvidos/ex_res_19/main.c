/*
19) Faça um programa que utilize uma matriz com dimensões máximas de cinco linhas e quatro colunas.
Solicite que sejam digitados os números que serão armazenados na matriz da seguinte maneira:

||se o número digitado for par, deve ser armazenado em uma linha de índice par;
 * 
|| se o número digitado for ímpar, deve ser armazenado em uma linha de índice ímpar;
 * 
|| as linhas devem ser preenchidas de cima para baixo (por exemplo, os números pares digitados
devem ser armazenados inicialmente na primeira linha par; quando essa linha estiver totalmente
preenchida, deve ser utilizada a segunda linha par e assim sucessivamente; o mesmo procedimento
deve ser adotado para os números ímpares);
 * 
|| quando não couberem mais números pares ou ímpares, o programa deverá mostrar uma mensagem
ao usuário;
 * 
|| quando a matriz estiver totalmente preenchida, o programa deverá encerrar a leitura dos números
e mostrar todos os elementos armazenados na matriz.
 */

#include <stdio.h>
#include <stdlib.h>
#define L 5
#define C 4

int main(int argc, char** argv) {

    return (EXIT_SUCCESS);
}

