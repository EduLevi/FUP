/*
23) Crie um programa que receba três valores (obrigatoriamente maiores que zero), representando as medi-
das dos três lados de um triângulo.
Elabore sub-rotinas para:

    || determinar se esses lados formam um triângulo (sabe-se que, para ser triângulo, a medida de um
lado qualquer deve ser inferior ou igual à soma das medidas dos outros dois).
    || determinar e mostrar o tipo de triângulo (equilátero, isósceles ou escaleno), caso as medidas for-
mem um triângulo.

Todas as mensagens deverão ser mostradas no programa principal.
 */

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char** argv) {


    return (EXIT_SUCCESS);
}
