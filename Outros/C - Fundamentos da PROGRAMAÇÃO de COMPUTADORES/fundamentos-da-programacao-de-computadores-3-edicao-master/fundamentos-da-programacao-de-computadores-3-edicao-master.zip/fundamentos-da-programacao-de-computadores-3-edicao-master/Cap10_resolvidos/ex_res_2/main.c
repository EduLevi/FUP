
#include <stdio.h>
#include <stdlib.h>
#define DIAS 30

typedef struct {
    int codigo;
    char descrcao[100];
} Dados;

Dados Servicos;

void Cadastro(Dados *Servicos);

int main(int argc, char** argv) {
    int opcao;
    
    
    return (EXIT_SUCCESS);
}

void Cadastro(Dados *Servicos) {
    
}
