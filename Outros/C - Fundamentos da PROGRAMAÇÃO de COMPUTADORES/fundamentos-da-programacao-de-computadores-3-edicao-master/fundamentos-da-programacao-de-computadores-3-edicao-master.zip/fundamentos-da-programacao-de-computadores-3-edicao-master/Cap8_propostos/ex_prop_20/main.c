/*
20) A prefeitura de uma cidade fez uma pesquisa entre seus habitantes, coletando dados sobre o salário e o
número de filhos. Faça uma sub-rotina que leia esses dados para um número não determinado de pessoas
e retorne a média de salário da população, a média do número de filhos, o maior salário e o percentual
de pessoas com salário inferior a R$ 380,00.
 */

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char** argv) {

    return (EXIT_SUCCESS);
}

